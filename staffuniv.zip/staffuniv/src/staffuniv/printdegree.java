
package staffuniv;

import DATA.degreedata;
import DATA.studentdata;
import arraydata.student;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PrinterException;
import java.text.MessageFormat;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import static jdk.nashorn.internal.runtime.Debug.id;

public class printdegree extends JPanel implements ActionListener  {
  JTable tab;
  JScrollPane sc;
    JButton print,refrache;
    String data[][];
    String header[] = {"id", "fname", "lname","adress","degree"};
    ArrayList<student> ar;

    public printdegree() {
        this.setLayout(null);
        show_tab();
    }
     //methode show table
    public void show_tab() {
        ar = studentdata.getstudentanddegree();
        // completed table with informaton 
        data = new String[ar.size()][5];
        for (int i = 0; i < ar.size(); i++) {
            data[i][0] = "" + ar.get(i).getId();
            data[i][1] = ar.get(i).getFname();
            data[i][2] = ar.get(i).getLname();
            data[i][3] = ar.get(i).getAdd();
            data[i][4] = ""+ar.get(i).getSom();      
        }
        //button emplimentation 
         print= new JButton("print degree ");
         refrache= new JButton("refrache");
         refrache.setBounds(250,10,100, 20);
       print.setBounds(135, 10,120, 20);
       refrache.setBackground(Color.green);
       refrache.setForeground(Color.BLUE);
       print.setBackground(Color.green);
       print.setForeground(Color.BLUE);
        add(print);
        add(refrache);
       print.addActionListener(this);
       refrache.addActionListener(this);
        //int table 
        tab = new JTable(data, header);
        sc = new JScrollPane(tab);
        sc.setBounds(20,40, 335, 250);
        add(sc);
        
        //config table with center word 
        ((DefaultTableCellRenderer) tab.getTableHeader().getDefaultRenderer())
                .setHorizontalAlignment((int) JLabel.CENTER_ALIGNMENT);
        DefaultTableCellRenderer df = new DefaultTableCellRenderer();
        df.setHorizontalAlignment(JLabel.CENTER);
        tab.getColumnModel().getColumn(0).setCellRenderer(df);
        for (int i = 0; i < tab.getColumnCount(); i++) {
            tab.getColumnModel().getColumn(i).setCellRenderer(df);
        }
        //tab.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT); diection de language

    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==print){
        MessageFormat f=new MessageFormat(" student degree");
         MessageFormat p=new MessageFormat("page{1}");
         try{
         tab.print(JTable.PrintMode.NORMAL,f,p);
         } catch (PrinterException ex) {
          System.out.print(ex.getMessage());
      }
        }
     if(e.getSource()==refrache){ 
     }         
       show_tab(); 
    }
    
}
