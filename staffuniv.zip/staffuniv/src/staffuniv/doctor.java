/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package staffuniv;

import javax.swing.JFrame;
import javax.swing.JTabbedPane;

/**
 *
 * @author Happy
 */
public class doctor extends JFrame{
    JTabbedPane tab;
    addst ad;
    degree dg;
    updatestudent ds;
  static String department;
  printdegree pr;
  updatedegree ud;
public doctor ( String s){
department=s;
    
 
}
  public void show_doctor() {
     ad=new addst();
    dg=new  degree(department) ;
    pr=new printdegree();
    ds=new updatestudent();
    ud=new  updatedegree();
     this.setTitle("doctor");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
        this.setSize(400, 280);
        this.setResizable(false);
tab=new JTabbedPane();
tab.addTab("student", ad);
tab.addTab("degree", dg);
tab.addTab("print", pr);
tab.addTab("update student", ds);
tab.addTab("update degree", ud);
    add(tab);
  } 
    
    
}
