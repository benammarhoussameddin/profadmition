package staffuniv;

import DATA.userdata;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class secsrup extends JFrame implements ActionListener {

    JLabel username, passwo, dept, note1, note2;
    JTextField user_name, password, department;
    JButton send, back;
    images img = new images();

    public secsrup() {
    }

    public void show_signup() {
        // in user and pass lable
        username = new JLabel("user_name");
        passwo = new JLabel("password");
        dept = new JLabel("depertment");
        note1 = new JLabel("entrer department(CS or ");
        note2 = new JLabel("IS or IT )only");
        username.setBounds(30, 50, 80, 25);
        passwo.setBounds(30, 80, 80, 25);
        dept.setBounds(30, 110, 80, 25);
        dept.setForeground(Color.BLACK);
        note1.setBounds(255, 110, 200, 10);
        note2.setBounds(255, 110, 200, 35);
        note1.setForeground(Color.GREEN);
        note2.setForeground(Color.GREEN);
        img.add(username);
        img.add(passwo);
        img.add(dept);
        img.add(note1);
        img.add(note2);

        // in user name and password textfiled
        user_name = new JTextField();
        password = new JTextField();
        department = new JTextField();
        user_name.setBounds(100, 50, 150, 25);
        password.setBounds(100, 80, 150, 25);
        department.setBounds(100, 110, 150, 25);
        img.add(user_name);
        img.add(password);
        img.add(department);
        send = new JButton("SAVE");
        send.setBounds(125, 150, 100, 25);
        img.add(send);
        back = new JButton("back");
        back.setBounds(0, 0, 65, 20);
        back.setBackground(Color.blue);
        img.add(back);
        send.addActionListener(this);
        back.addActionListener(this);
        this.setTitle("signup");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
        this.setSize(412, 250);
        this.setResizable(false);
        add(img);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == back) {
            this.dispose();
            new firstsclog().show_log();
        }
        if (e.getSource() == send) {
            try {
                String t = department.getText();
                if (t.equalsIgnoreCase("cs") || t.equalsIgnoreCase("is") || t.equalsIgnoreCase("it")) {
                    userdata.insert_user(user_name.getText(), password.getText(), department.getText());
                    JOptionPane.showMessageDialog(null, " hello  " + user_name.getText(), "new  user", JOptionPane.INFORMATION_MESSAGE);
                    this.dispose();
                    new firstsclog().show_log();
                } else {
                    JOptionPane.showMessageDialog(null, " department is not existe", "error department", JOptionPane.WARNING_MESSAGE);

                }

            } catch (SQLException ex) {
                System.out.print(ex.getMessage());
            }

        }
    }
}
