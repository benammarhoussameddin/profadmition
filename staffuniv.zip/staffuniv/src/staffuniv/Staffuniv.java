package staffuniv;

public class Staffuniv {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //run fistlog
        new firstsclog().show_log();
      // new secsrup().show_signup();
    }

}
