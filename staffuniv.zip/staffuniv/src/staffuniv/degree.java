package staffuniv;

import DATA.degreedata;
import DATA.studentdata;
import arraydata.student;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableCellRenderer;

public class degree extends JPanel implements ActionListener {

    //table and lable and texte filed and button 
    JTable tab;
    JScrollPane sc;
    static String depart;
    JLabel m1, m2, m3, m4, m5, m6;
    JTextField t1, t2, t3, t4, t5, t6;
    JButton adddegree;
    int j = 0;
    String data[][];
    String header[] = {"id", "fname", "lname"};
    ArrayList<student> ar;

    public degree(String s) {
        this.depart = s;
        this.setLayout(null);
        show_tab();
    }

    //methode show table
    public void show_tab() {
        ar = studentdata.getstudent(depart);
        // completed table with informaton 
        data = new String[ar.size()][3];
        for (int i = 0; i < ar.size(); i++) {
            data[i][0] = "" + ar.get(i).getId();
            data[i][1] = ar.get(i).getFname();
            data[i][2] = ar.get(i).getLname();

        }
        //int table 
        tab = new JTable(data, header);
        sc = new JScrollPane(tab);
        sc.setBounds(0, 0, 250, 300);
        add(sc);
        //init jlable and jtext field and jbutton for degree
        m1 = new JLabel("IS");
        m2 = new JLabel("NC");
        m3 = new JLabel("IT");
        m4 = new JLabel("SC");
        m5 = new JLabel("SA");
        m6 = new JLabel("AI");
        m1.setBounds(270, 10, 50, 20);
        m2.setBounds(270, 40, 50, 20);
        m3.setBounds(270, 70, 50, 20);
        m4.setBounds(270, 100, 50, 20);
        m5.setBounds(270, 130, 50, 20);
        m6.setBounds(270, 160, 50, 20);
        add(m1);
        add(m2);
        add(m3);
        add(m4);
        add(m5);
        add(m6);
        t1 = new JTextField();
        t2 = new JTextField();
        t3 = new JTextField();
        t4 = new JTextField();
        t5 = new JTextField();
        t6 = new JTextField();
        t1.setBounds(300, 10, 50, 20);
        t2.setBounds(300, 40, 50, 20);
        t3.setBounds(300, 70, 50, 20);
        t4.setBounds(300, 100, 50, 20);
        t5.setBounds(300, 130, 50, 20);
        t6.setBounds(300, 160, 50, 20);
        add(t1);
        add(t2);
        add(t3);
        add(t4);
        add(t5);
        add(t6);
        adddegree = new JButton("add degree");
        adddegree.setBounds(275, 190, 100, 20);
        adddegree.setBackground(Color.green);
        adddegree.setForeground(Color.BLUE);
        add(adddegree);
        adddegree.addActionListener(this);
        //config table with center word 
        ((DefaultTableCellRenderer) tab.getTableHeader().getDefaultRenderer())
                .setHorizontalAlignment((int) JLabel.CENTER_ALIGNMENT);
        DefaultTableCellRenderer df = new DefaultTableCellRenderer();
        df.setHorizontalAlignment(JLabel.CENTER);
        tab.getColumnModel().getColumn(0).setCellRenderer(df);
        for (int i = 0; i < tab.getColumnCount(); i++) {
            tab.getColumnModel().getColumn(i).setCellRenderer(df);
        }
        //tab.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT); diection de language
        //event table with mouseclicked
        tab.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ttmouseClicked(evt);
            }

        });

    }

    private void ttmouseClicked(java.awt.event.MouseEvent evt) {
        j = tab.getSelectedRow();
        System.out.println("ok" + tab.getSelectedRow());
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        System.out.println(j);
        try {
            int id = ar.get(j).getId();
            degreedata.insert_degree(id, Integer.parseInt(t1.getText()), Integer.parseInt(t2.getText()),
                    Integer.parseInt(t3.getText()), Integer.parseInt(t4.getText()), Integer.parseInt(t5.getText()), Integer.parseInt(t6.getText()));
             JOptionPane.showMessageDialog(null,"inserted degree" , "new degree", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

}
