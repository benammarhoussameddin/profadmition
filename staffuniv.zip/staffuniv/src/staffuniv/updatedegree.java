
package staffuniv;

import DATA.degreedata;
import arraydata.degreeup;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class updatedegree extends JPanel implements ActionListener{
 JLabel m1, m2, m3, m4, m5, m6,i;
    JTextField t1, t2, t3, t4, t5, t6,id;
    JButton search_id,update_degree;
     ArrayList<degreeup> ag;
    public updatedegree() {
     this.setLayout(null);
     //init jlable and jtext field and jbutton for degree
        i = new JLabel(" enter id student");
        m1 = new JLabel("IS");
        m2 = new JLabel("NC");
        m3 = new JLabel("IT");
        m4 = new JLabel("SC");
        m5 = new JLabel("SA");
        m6 = new JLabel("AI");
        i.setBounds(150, 10, 100, 20);
        m1.setBounds(50, 50, 50, 20);
        m2.setBounds(50, 70, 50, 20);
        m3.setBounds(50, 90, 50, 20);
        m4.setBounds(50, 110, 50, 20);
        m5.setBounds(50, 130, 50, 20);
        m6.setBounds(50, 150, 50, 20);
        add(i);
        add(m1);
        add(m2);
        add(m3);
        add(m4);
        add(m5);
        add(m6);
        id = new JTextField();
        t1 = new JTextField();
        t2 = new JTextField();
        t3 = new JTextField();
        t4 = new JTextField();
        t5 = new JTextField();
        t6 = new JTextField();
        id.setBounds(250, 10, 50, 20);
        t1.setBounds(100, 50, 50, 20);
        t2.setBounds(100, 70, 50, 20);
        t3.setBounds(100, 90, 50, 20);
        t4.setBounds(100, 110, 50, 20);
        t5.setBounds(100, 130, 50, 20);
        t6.setBounds(100, 150, 50, 20);
        add(id);
        add(t1);
        add(t2);
        add(t3);
        add(t4);
        add(t5);
        add(t6);
        //button searche and update degree
         search_id = new JButton("search");
        search_id.setBounds(300,10,80, 20);
        search_id.setBackground(Color.green);
        search_id.setForeground(Color.BLUE);
        add(search_id);
        search_id.addActionListener(this);
        
        update_degree = new JButton("update_degree");
        update_degree.setBounds(140, 180, 130, 20);
        update_degree.setBackground(Color.green);
        update_degree.setForeground(Color.BLUE);
        add(update_degree);
        update_degree.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==search_id){
       ag= degreedata.getdegree(Integer.parseInt(id.getText()));
       t1.setText(""+ag.get(0).getM1());
        t2.setText(""+ag.get(0).getM2());
         t3.setText(""+ag.get(0).getM3());
          t4.setText(""+ag.get(0).getM4());
           t5.setText(""+ag.get(0).getM5());
            t6.setText(""+ag.get(0).getM6());
        }
       if(e.getSource()==update_degree){
            try {
                degreedata.update_degree(Integer.parseInt(id.getText()),Integer.parseInt(t1.getText()),Integer.parseInt(t2.getText()),Integer.parseInt(t3.getText()),Integer.parseInt(t4.getText()),Integer.parseInt(t5.getText()),Integer.parseInt(t6.getText()));
            } catch (SQLException ex) {
                Logger.getLogger(updatedegree.class.getName()).log(Level.SEVERE, null, ex);
            }
           JOptionPane.showMessageDialog(null," update degree " , " update degree ", JOptionPane.INFORMATION_MESSAGE);
           t1.setText("");
            t2.setText("");
             t3.setText("");
              t4.setText("");
               t5.setText("");
                t6.setText("");
                id.setText("");
       } 
        
    }
    
    
}
