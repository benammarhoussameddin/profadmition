package staffuniv;

import java.awt.Graphics;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class images extends JPanel {

    private ImageIcon image;

    public images() {
        this.setLayout(null);
       
    }

    @Override
    public void paintComponent(Graphics grphcs) {
        super.paintComponent(grphcs);
         image = new ImageIcon(getClass().getResource("..\\\\imge\\\\reunion.jpg"));
        // ..\\imge\\reunion.jpg
        image.paintIcon(this, grphcs, 0, 0);
    }
}
