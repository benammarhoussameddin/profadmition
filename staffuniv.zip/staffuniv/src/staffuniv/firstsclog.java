package staffuniv;

import DATA.userdata;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class firstsclog extends JFrame implements ActionListener{

    images img = new images();
    JLabel user, pass;
    JTextField user_name;
    JPasswordField password;
    JButton singin, singup;

    public firstsclog() {

    }

    public void show_log() {
        // in user and pass lable
        user = new JLabel("user_name");
        pass = new JLabel("password");
        user.setBounds(92, 50, 80, 50);
        pass.setBounds(95, 83, 80, 50);
        img.add(user);img.add(pass);
        // in user name and password textfiled
        user_name=new JTextField ();
         password=new JPasswordField();
         user_name.setBounds(160, 65, 150, 25);
         password.setBounds(160, 95, 150, 25);
         img.add(user_name);img.add(password);
         // singin and singup button
         singin=new JButton("signin");
         singup=new JButton("signup");
         singin.setBounds(140, 145, 70, 25);
         singup.setBounds(255, 145, 75, 25);
         img.add(singin);img.add(singup);
         singin.addActionListener(this);
         singup.addActionListener(this);
        this.setTitle("université staff");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
        this.setSize(412, 250);
        this.setResizable(false);
        add(img);
    }
// button action 
    @Override
    public void actionPerformed(ActionEvent e) {
        
         if(e.getSource()==singin){
        int m=userdata.chek_user(user_name.getText(), password.getText());
             switch (m) {
                 case 1:
                 JOptionPane.showMessageDialog(null, " hello  " + user_name.getText(), "user", JOptionPane.INFORMATION_MESSAGE);
                     this.dispose();
        {
            try {
                new doctor(userdata.get_depertment(user_name.getText())).show_doctor();
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
                     break;
                 case 2:
                      JOptionPane.showMessageDialog(null, "password wron", "wron password", JOptionPane.WARNING_MESSAGE);
                     System.out.println("password wron");
                     break;
                 default:
                     JOptionPane.showMessageDialog(null, "user_name not existe", "wron user", JOptionPane.WARNING_MESSAGE);
                     break;
             }
     
        }
        if(e.getSource()==singup){
            this.dispose();
        new secsrup().show_signup();
        }
    }
}
