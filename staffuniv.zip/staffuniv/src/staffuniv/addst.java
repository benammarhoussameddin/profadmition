
package staffuniv;

import DATA.studentdata;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class addst extends JPanel implements ActionListener{
    JLabel fname,lname,add,dept;
    JTextField firstname,lasetname,adrres,department;
    JButton save;
  public  addst(){
      this.setLayout(null);
      // stduent jlable
        fname= new JLabel("firsetname");
        lname = new JLabel("last name");
         add = new JLabel("adress");
        dept = new JLabel("depertment");
        fname.setBounds(65, 20, 80, 25);
        lname.setBounds(65, 50, 80, 25);
        add.setBounds(65, 80, 80, 25);
         dept.setBounds(60, 110, 80, 25);
        add(fname); add(lname);add(add);add(dept);
        // student jtextfield
        firstname = new JTextField();
        lasetname= new JTextField();
        adrres = new JTextField();
        department = new JTextField();
        firstname.setBounds(130, 20, 150, 25);
        lasetname.setBounds(130, 50, 150, 25);
         adrres.setBounds(130, 80, 150, 25);
        department.setBounds(130, 110, 150, 25);
        add(firstname);
        add(lasetname);
        add(adrres);
        add(department);
        //student button 
           save=new JButton("SAVE ");
         save.setBounds(150, 150, 100, 25);
         add(save);
         save.addActionListener( this);
}

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==save){
            try {
                studentdata.insert_student(firstname.getText(),lasetname.getText(),adrres.getText(), department.getText());
                JOptionPane.showMessageDialog(null, " hello  " + firstname.getText() + lasetname.getText() , "new doctor ", JOptionPane.INFORMATION_MESSAGE);
            } catch (SQLException ex) {
              System.out.println(ex.getMessage());
            }
        }
       
    }
  } 
 
