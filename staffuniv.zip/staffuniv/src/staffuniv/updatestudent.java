
package staffuniv;

import DATA.studentdata;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class updatestudent  extends JPanel implements ActionListener {
 JLabel fname,lname,add,dept,i;
    JTextField firstname,lasetname,adrres,department,id;
    JButton save;
    public updatestudent() {
        this.setLayout(null);
      // stduent jlable
      i= new JLabel("id student");
        fname= new JLabel("firsetname");
        lname = new JLabel("last name");
         add = new JLabel("adress");
        dept = new JLabel("depertment");
        i.setBounds(65, 20, 80, 25);
        fname.setBounds(65, 50, 80, 25);
        lname.setBounds(65, 80, 80, 25);
        add.setBounds(65, 110, 80, 25);
         dept.setBounds(60, 140, 80, 25);
        add(fname); add(lname);add(add);add(dept);add(i);
        // student jtextfield
         id = new JTextField();

        firstname = new JTextField();
        lasetname= new JTextField();
        adrres = new JTextField();
        department = new JTextField();
        id.setBounds(135, 20, 150, 25);
        firstname.setBounds(135, 50, 150, 25);
        lasetname.setBounds(135, 80, 150, 25);
         adrres.setBounds(135, 110, 150, 25);
        department.setBounds(135, 140, 150, 25);
        add(firstname);
        add(lasetname);
        add(adrres);
        add(department);
        add(id);
        //student button 
           save=new JButton(" update student ");
         save.setBounds(150, 180, 125, 25);
         add(save);
         save.addActionListener( this);
        
    }
    

    @Override
    public void actionPerformed(ActionEvent ae) {
         studentdata.update_sudent(Integer.parseInt(id.getText()),firstname.getText(),lasetname.getText(),adrres.getText(),department.getText());
         JOptionPane.showMessageDialog(null, " the updated student is " + firstname.getText() + lasetname.getText() , " update student ", JOptionPane.INFORMATION_MESSAGE);
          id.setText("");
            firstname.setText("");
             lasetname.setText("");
              adrres.setText("");
               department.setText("");
                
    }
    
}
