
package arraydata;

public class student {
    private int id ;
            int som;
      private String fname,lname,add,dept;
    public student(int id, String fname, String lname, String add, String dept,int som) {
        this.id = id;
        this.fname = fname;
        this.lname = lname;
        this.add = add;
        this.dept = dept;
        this.som=som;
    }

    public int getSom() {
        return som;
    }

    public void setSom(int som) {
        this.som = som;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getAdd() {
        return add;
    }

    public void setAdd(String add) {
        this.add = add;
    }

    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }
  
    
}
