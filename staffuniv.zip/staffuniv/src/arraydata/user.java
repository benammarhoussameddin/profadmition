
package arraydata;

public class user {
   private String username,password,deraprtment; 

    public user(String username, String password, String deraprtment) {
        this.username = username;
        this.password = password;
        this.deraprtment = deraprtment;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDeraprtment() {
        return deraprtment;
    }

    public void setDeraprtment(String deraprtment) {
        this.deraprtment = deraprtment;
    }
   
}
