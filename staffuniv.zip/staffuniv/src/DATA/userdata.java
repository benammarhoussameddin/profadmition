package DATA;

import arraydata.user;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JTextField;

public class userdata {

    public static void insert_user(JTextField user_name, JTextField password, JTextField department) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    public userdata() {
    }

    public static Connection conect() throws SQLException {
        return DriverManager.getConnection("jdbc:sqlite:project1.sqlite");
    }

    public static void insert_user(String user, String pass, String dept) throws SQLException {
        try (
                Connection con = conect();
                PreparedStatement ps = con.prepareStatement("insert into user values(?,?,?)");) {
            ps.setString(1, user);
            ps.setString(2, pass);
            ps.setString(3, dept);
            ps.execute();
        } catch (SQLException ee) {
            System.out.println(ee.getMessage());
        }
    }

    public static ArrayList<user> getdatauser() {
        ArrayList<user> liste = new ArrayList<user>();
        try (
                Connection con = conect();
                PreparedStatement ps = con.prepareStatement("select*from user");) {
            ResultSet r = ps.executeQuery();
            while (r.next()) {
                liste.add(new user(r.getString("user_name"), r.getString("password"), r.getString("department")));

            }

        } catch (SQLException ee) {
            System.out.println(ee.getMessage());
        }
        return liste;
    }

    public static int chek_user(String user, String pass) {
        ArrayList<user> arr = getdatauser();
        int j = 0;
        for (int i = 0; i < arr.size(); i++) {
            if (arr.get(i).getUsername().equalsIgnoreCase(user)) {
                if (arr.get(i).getPassword().equalsIgnoreCase(pass)) {
                    j = 1;
                    break;
                } else {
                    j = 2;
                    break;
                }
            } else {
                j = 3;
            }

        }
        return j;

    }

    public static String get_depertment(String user) throws SQLException {
        try (
                Connection con = conect();
                PreparedStatement p = con.prepareStatement("select department from user where user_name=?");) {
            p.setString(1, user);
            ResultSet r = p.executeQuery();
            return r.getString("department");
        } catch (SQLException ee) {
            System.out.println(ee.getMessage());
        }
        return null;
    }
}
