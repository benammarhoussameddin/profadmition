
package DATA;

import arraydata.degreeup;
import arraydata.student;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class studentdata {

    public studentdata() {
    }

    public static Connection conect() throws SQLException {
        return DriverManager.getConnection("jdbc:sqlite:project1.sqlite");
    }

    public static void insert_student(String fname, String lname, String add, String dept) throws SQLException {
        try (
            Connection con = conect();
            PreparedStatement ps = con.prepareStatement("insert into student(fname,lname,adresse,department) values(?,?,?,?)");){
            ps.setString(1, fname);
            ps.setString(2, lname);
            ps.setString(3, add);
            ps.setString(4, dept);
            ps.execute();
        } catch (SQLException ee) {
            System.out.println(ee.getMessage());
        }
    }

    public static ArrayList<student> getstudent(String d) {
        ArrayList<student> liste = new ArrayList<student>();
        try (
            Connection con = conect();
            PreparedStatement ps = con.prepareStatement("select*from student where department=?");){
            ps.setString(1,d);
            ResultSet r = ps.executeQuery();
            while (r.next()) {
                liste.add(new student(r.getInt("id"), r.getString("fname"), r.getString("lname"), r.getString("adresse"), r.getString("department"),r.getInt("id")));

            }

        } catch (SQLException ee) {
            System.out.println(ee.getMessage());
        }
        return liste;
    }
    
    public static ArrayList<student> getstudentanddegree() {
        ArrayList<student> liste = new ArrayList<student>();
        try (
            Connection con = conect();
            PreparedStatement ps = con.prepareStatement("select*from student,degree where degree.id=student.id");){
            ResultSet r = ps.executeQuery();
            while (r.next()) {
                
                liste.add(new student(r.getInt("id"), r.getString("fname"), r.getString("lname"), r.getString("adresse"), r.getString("department"),r.getInt("som")));

            }

        } catch (SQLException ee) {
            System.out.println(ee.getMessage());
        }
        return liste;
    }
    public static void update_sudent(int id,String fname, String lname, String add, String dept){
      try (
            Connection con = conect();
            PreparedStatement ps = con.prepareStatement("update student set fname=? ,lname=? ,adresse=? ,department=? where id=?");){
            ps.setString(1, fname);
            ps.setString(2, lname);
            ps.setString(3, add);
            ps.setString(4, dept);
            ps.setInt(5, id);
            ps.execute();
        } catch (SQLException ee) {
            System.out.println(ee.getMessage());
        }
    }
 

}
