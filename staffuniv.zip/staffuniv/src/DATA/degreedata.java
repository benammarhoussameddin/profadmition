package DATA;

import static DATA.studentdata.conect;
import arraydata.degreeup;
import arraydata.student;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import staffuniv.degree;

public class degreedata {

    public static Connection conect() throws SQLException {
        return DriverManager.getConnection("jdbc:sqlite:project1.sqlite");
    }

    public static void insert_degree(int id, int m1, int m2, int m3, int m4, int m5, int m6) throws SQLException {
        try (
                
                Connection con = conect();
                PreparedStatement ps = con.prepareStatement("insert into degree values(?,?,?,?,?,?,?,?)");) {
            ps.setInt(1, id);
            ps.setInt(2, m1);
            ps.setInt(3, m2);
            ps.setInt(4, m3);
            ps.setInt(5, m4);
            ps.setInt(6, m5);
            ps.setInt(7, m6);
            ps.setInt(8, m1 + m2 + m3 + m4 + m5 + m6);
            ps.execute();
        } catch (SQLException ee) {
            System.out.println(ee.getMessage());
        }
    }
    
    public static ArrayList<degreeup> getdegree(int id) {
        ArrayList<degreeup> liste = new ArrayList<degreeup>();
        try (
            Connection con = conect();
            PreparedStatement ps = con.prepareStatement("select*from degree where id=?");){
            ps.setInt(1,id);
            ResultSet r = ps.executeQuery();
            while (r.next()) {
                liste.add(new degreeup(r.getInt("id"), r.getInt("m1"), r.getInt("m2"), r.getInt("m3"), r.getInt("m4"),
                r.getInt("m5"),r.getInt("m6")));

            }

        } catch (SQLException ee) {
            System.out.println(ee.getMessage());
        }
        return liste;
    }
         public static void update_degree(int id, int m1, int m2, int m3, int m4, int m5, int m6) throws SQLException {
        try (
                Connection con = conect();
                PreparedStatement ps = con.prepareStatement("update degree set m1=? ,m2=? ,m3=? ,m4=?, m5=?,m6=?,som=? where id=?");) {
            ps.setInt(1, m1);
            ps.setInt(2, m2);
            ps.setInt(3, m3);
            ps.setInt(4, m4);
            ps.setInt(5, m5);
            ps.setInt(6, m6);
              ps.setInt(7, m1 + m2 + m3 + m4 + m5 + m6);
            ps.setInt(8, id);
           
            ps.execute();
        } catch (SQLException ee) {
            System.out.println(ee.getMessage());
        }
    }
}
